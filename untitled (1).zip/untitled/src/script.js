const stories = [
  {
    title: "Gül Güzeli",
    teaser: "Güllerle başlayan bir mucize, kıskançlıkla sınanan bir kader…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 36.",
    paragraphs: [
      "Bir zamanlar üç kızı olan bir padişah yaşarmış. Küçük kızının dileği diğerlerinden farklıymış. Kendi hayatı hakkında karar vermek isteyince babası öfkelenmiş ve onu saraydan uzaklaştırarak yoksul bir köylüyle evlendirmiş. Genç kız, saraydaki bütün imkânlarını geride bırakıp mütevazı bir kulübede yaşamaya başlamış.",
      "Zaman geçtikçe genç kadının doğum vakti gelmiş. Kocası yardım bulmak için evden ayrılınca kadın çaresiz kalmış. Tam o sırada üç peri ortaya çıkmış ve ona yardım etmiş. Periler yeni doğan kız çocuğuna olağanüstü özellikler vermiş: Ağladığında gözyaşları inciye dönüşecek, gülümsediğinde yanaklarında güller belirecekmiş. Bu nedenle ona Gül Güzeli adını vermişler.",
      "Gül Güzeli büyüdükçe güzelliği ve sıra dışı özellikleri herkesin dikkatini çekmiş. Ünü bir şehzadeye kadar ulaşmış ve şehzade onunla evlenmek istemiş. Ancak sarayda yaşayan kıskanç bir kadın kendi kızını şehzadeyle evlendirmek istediğinden Gül Güzeli'ni ortadan kaldırmak için plan yapmış. Hileler sonucunda genç kızın hayatı altüst olmuş ve rakibi onun yerini almaya çalışmış.",
      "Gül Güzeli saraydan uzaklaştırıldıktan sonra da olağanüstü özelliklerini korumuş. Onunla bağlantılı bir yavru geyiğin öldürülmesi, genç kızın da hayatını kaybetmesine neden olmuş. Ancak hikâyedeki sırlar zamanla açığa çıkmış ve Gül Güzeli'nin gerçek kimliği anlaşılmış. Onunla bağlantılı küçük bir mercan taşı, yeniden hayata dönmesinde önemli rol oynamış.",
      "Sonunda şehzade sevdiği kadına ve kızına kavuşmuş; kötülük yapanların hileleri ortaya çıkmış. Masal, kıskançlığın yıkıcı etkisini ve umudun yeniden kavuşmayı mümkün kılabileceğini anlatır."
    ]
  },
  {
    title: "Yarım Akıllı Mehmet",
    teaser: "Saf görünen bir gencin beklenmedik maceraları…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 45.",
    paragraphs: [
      "Mehmet, babalarından kalan malları paylaşmak isteyen iki kardeşten küçük olanıdır. İnsanlar onu pek akıllı bulmazmış; çünkü olayları çoğu zaman farklı yorumlar ve düşünmeden hareket edermiş. Kardeşler hayvanlarını iki ahıra ayırmaya karar verdiklerinde Mehmet, yeni ahıra giren hayvanların kendisine kalmasını önermiş. Ancak kardeşinin yönlendirmesiyle hayvanların çoğu diğer ahıra gitmiş ve Mehmet'e yalnızca yaşlı, kör bir öküz kalmış.",
      "Mehmet öküzünü alıp otlatmaya başlamış. Bir gün büyük bir ağacın yanına gelmiş. Rüzgârın etkisiyle uğuldayan ağaca seslenmiş, fakat yanıt alamayınca baltasıyla ağaca vurmuş. Ağacın gövdesinden altınlar çıkmaya başlamış. Mehmet bu beklenmedik hazineyi toplamış ve böylece yoksulluktan kurtulma fırsatı yakalamış.",
      "Mehmet'in başına gelenler yalnızca bu hazineyle sınırlı kalmamış. Yolculuğu sırasında olağanüstü bir varlıktan çeşitli sihirli eşyalar edinmiş. Bunlardan biri, istenildiğinde yemeklerle dolan bir masa olmuş. Mehmet bu eşya sayesinde köydeki insanlara da ziyafet vermiş. Ne var ki bazı kişiler onun iyiliğini fırsat bilmiş ve sihirli eşyalarını ele geçirmişler.",
      "Mehmet her kayıptan sonra yardım almak için yeniden yola koyulmuş. Kendisine verilen yeni eşyalar da çevresindeki açgözlü insanların ilgisini çekmiş. Her defasında yaşadığı güçlükleri aşmanın bir yolunu aramış ve elindeki imkânları yeniden kazanmak için uğraşmış.",
      "Masal, dışarıdan saf görünen birinin beklenmedik biçimde başarıya ulaşabileceğini anlatır. Aynı zamanda başkalarının iyiliğini fırsat bilen kişilerin açgözlülüğünü eleştirir."
    ]
  },
  {
    title: "Altın Saçlı Kardeşler",
    teaser: "Ay ve yıldızla anılan iki çocuğun saklı hikâyesi…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 54.",
    paragraphs: [
      "Bir zamanlar üç kızı olan yoksul bir oduncu yaşarmış. Kızlar geçimlerini sağlamak için dikiş diker ve nakış işlermiş. Bir gün padişahın koyduğu yasağa rağmen karanlıkta çalışabilmek için küçük bir ışık yakmışlar. Şehri dolaşan padişah evlerinden sızan ışığı fark etmiş ve konuşmalarını duymuş.",
      "Kız kardeşler hayallerinden söz ediyorlarmış. Büyük kardeş sarayın aşçısıyla, ortanca kardeş sarayın kıyafetlerinden sorumlu kişiyle evlenmek istiyormuş. Küçük kardeş ise padişahla evlenip altın saçlı iki çocuk dünyaya getirmeyi hayal ediyormuş. Padişah bu dilekleri duyunca kız kardeşleri sarayına çağırmış ve küçük kardeşle evlenmiş.",
      "Ancak büyük kardeşler küçük kardeşlerinin mutluluğunu kıskanmış. Küçük kız altın saçlı bir kız ve bir erkek çocuk dünyaya getirdiğinde, kötü niyetli bir kadının yardımıyla bebekleri annelerinden ayırmışlar. Bebeklerin yerine yavru köpekler bırakılmış ve padişaha eşinin köpek doğurduğu söylenmiş. Aldatılan padişah öfkelenerek karısına ağır bir ceza vermiş.",
      "Çocuklar uzak bir yerde terk edilmiş; neyse ki bir keçinin yardımıyla hayatta kalmışlar. Onları bulan yaşlı bir çift büyütmüş. Altın saçlı kardeşler zamanla güçlenmiş ve bir gün gerçek babaları olan padişahla karşılaşmışlar. Çocukların sıra dışı özellikleri padişahın dikkatini çekmiş ve araştırmalar sonucunda geçmişteki gerçek ortaya çıkmış.",
      "Yıllarca birbirinden ayrı kalan aile yeniden bir araya gelmiş. Masal, kıskançlığın aile bağlarını bozabileceğini ve gerçeğin zamanla ortaya çıkabileceğini anlatır. Sevgi ve merhamet ise zor koşullarda bile yaşamın sürmesini sağlayabilir."
    ]
  },
  {
    title: "At-Cin ile Cadı",
    teaser: "Gizemli bir eş, tehlikeli bir sır ve zorlu bir kaçış…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 69.",
    paragraphs: [
      "Bir padişahın üç kızı varmış. Kızlardan biri, görünüşü sıradan bir insandan farklı olan ve atla ilişkilendirilen gizemli bir varlıkla evlenmiş. Genç kadın zamanla eşinin olağanüstü güçlere sahip olduğunu öğrenmiş. Kocası, kendi dünyasına ilişkin sırları başkalarına anlatmaması gerektiğini ona tembihlemiş.",
      "Genç adamın annesi bir cadıymış ve oğlunun bir insanla evlenmesini istemiyormuş. Gelinini ortadan kaldırmak için fırsat kollamış. Bir gün oğlunun evden ayrılmasını bekleyip gelinine yapması güç işler vermiş. Kadın, kendisinden istenenleri nasıl yapacağını bilemeyince kocasının daha önce verdiği saç tellerini yakarak yardım istemiş. Kocası her seferinde ortaya çıkıp ona yardım etmiş.",
      "Cadı, gelininin bu işleri kendi başına yapamayacağını anlamış ve oğlunun yardım ettiğinden şüphelenmiş. Sonunda genç adam, annesinin eşine zarar vermesini önlemek için karısıyla birlikte kaçmaya karar vermiş. Ancak cadı ve onun cadı olan akrabaları çiftin peşine düşmüş.",
      "Kaçış boyunca genç adam, olağanüstü yeteneklerini kullanarak kendisini ve eşini farklı kılıklara sokmuş. Böylece takipçilerinin onları bulmasını zorlaştırmış. Çift, kendilerini kurtarabilmek için hem akıllarını hem de birbirlerine duydukları güveni kullanmak zorunda kalmış.",
      "Masal, aile içindeki kıskançlık ve baskının insanları zor durumda bırakabileceğini gösterir. Sevgi, dayanışma ve birlikte çözüm üretmek ise zorlukları aşmada önemli rol oynar."
    ]
  },
  {
    title: "Kül Oğlan",
    teaser: "Küçümsenen bir gencin kahramanlığa uzanan yolu…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 76.",
    paragraphs: [
      "Bir zamanlar üç oğlu ve bir kızı olan yoksul bir kadın yaşarmış. Ailenin en küçük oğlu diğerlerinden farklıymış ve çevresindekiler onu aklı pek yerinde olmayan biri olarak görürmüş. Buna rağmen Kül Oğlan, başına gelen olaylar karşısında yılmayan ve harekete geçmekten çekinmeyen bir gençmiş.",
      "Kül Oğlan'ın hayatı, olağanüstü olaylarla ve tehlikeli görevlerle dolu bir maceraya dönüşmüş. Bu yolculukta yalnızca kendi yaşamını değil, zor durumda bulunan başkalarının hayatını da değiştirecek fırsatlarla karşılaşmış. Özellikle padişahın kızlarının içinde bulunduğu tehlike, onun cesaretini ve kararlılığını ortaya çıkarmış.",
      "Yolculuğu boyunca çeşitli olağanüstü varlıklarla ve güçlüklerle karşılaşan genç, prensesleri kurtarmaya yönelik çabalarını sürdürmüş. Bazen bedensel gücünü, bazen de aklını ve kararlılığını kullanarak tehlikelerden kurtulmuş. Ancak bütün güçlükler dışarıdan gelen düşmanlarla sınırlı kalmamış; kardeşler arasındaki ilişkiler de önemli rol oynamış.",
      "Kül Oğlan'ın başarısı sonunda herkesin dikkatini çekmiş. Padişah, kızlarının kurtarılmasının ardından genç adamın yaptıklarını öğrenmiş ve ona büyük bir ödül vermiş. Kül Oğlan'ın ailesi için yeni bir hayat kurmasının önü açılmış; annesini ve kız kardeşini yanına almış.",
      "Masal, dış görünüşü veya başkalarının yargıları nedeniyle küçümsenen bir kişinin gerçek değerinin başarılarıyla ortaya çıkabileceğini anlatır. Cesaret ve güçlükler karşısında pes etmemek, hikâyenin temel mesajlarıdır."
    ]
  },
  {
    title: "Bir Parça Ciğer İçin",
    teaser: "Basit bir istekle başlayan, uzayıp giden bir yolculuk…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 86.",
    paragraphs: [
      "Bir zamanlar yaşlı bir kadının canı ciğer yemek istemiş. Kızına para vererek çarşıdan ciğer almasını ve eve getirmeden önce gölde yıkamasını söylemiş. Genç kız söyleneni yapmış, ancak gölün kenarında bir leylek gelerek ciğeri kapmış ve uçup gitmiş. Kız, annesinin kendisini cezalandırmasından korktuğu için leyleğin arkasından seslenmiş ve ciğerini geri istemiş.",
      "Leylek, ciğeri geri vermek için kendisinden arpa getirmesini istemiş. Bunun üzerine kız bir çiftçiye gitmiş. Çiftçi, arpa verebilmek için yağmura ihtiyacı olduğunu söylemiş. Genç kız yağmurun yağması için dua etmeye başlamış. Bir adam ona, duasının gökyüzüne ulaşması için tütsü yakması gerektiğini söylemiş.",
      "Kız bu kez tütsü bulmak amacıyla çarşıya dönmüş. Tütsü satıcısı da tütsüyü verebilmek için ayakkabıcıdan bir bot getirmesini istemiş. Ayakkabıcı ise bot karşılığında bir öküz postuna ihtiyaç duyduğunu belirtmiş. Böylece kız, ciğerine ulaşabilmek için birbirine bağlı birçok isteği yerine getirmek zorunda kalmış.",
      "Her yeni kişi, ona yardım etmeden önce başka bir ihtiyaçtan söz etmiş. Kızın amacı çok basit olmasına rağmen çözmesi gereken sorunlar giderek artmış. Genç kız pes etmemiş; birinden diğerine giderek ihtiyacı olan şeyleri bulmaya çalışmış.",
      "Sonunda yağmurun yağmasını sağlamış, çiftçiden arpa almış ve arpayı leyleğe götürmüş. Leylek de sözünü tutarak ciğeri geri vermiş. Masal, sabırlı olmanın, başladığı işi yarım bırakmamanın ve karşılaşılan güçlükler karşısında çözüm aramaya devam etmenin önemini vurgular."
    ]
  },
  {
    title: "Rüzgâr İblisi",
    teaser: "Kaçırılan bir eş, güçlü bir düşman ve tehlikeli bir arayış…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 98.",
    paragraphs: [
      "Bir padişahın üç kızı varmış. Olağanüstü olayların ardından genç bir şehzade padişahın en küçük kızıyla evlenmiş. Ancak evlilikleri uzun süre huzur içinde devam etmemiş. Rüzgâr İblisi adı verilen güçlü ve tehlikeli bir varlık, şehzadenin eşini kaçırmış.",
      "Eşinden ayrı kalan genç adam, onu kurtarmak için uzun bir yolculuğa çıkmış. Karşılaştığı kişilerden yardım istemiş, fakat birçok kişi Rüzgâr İblisi'nin gücünün karşısında durmanın imkânsız olduğunu söylemiş. Şehzade yine de karısını geride bırakmayı kabul etmemiş.",
      "Yolculuğu sırasında kardeşleriyle ve çeşitli olağanüstü varlıklarla karşılaşmış. Güçlü yardımcılar onun arayışında önemli bir yer tutmuş. Şehzade, kendisine verilen bilgileri dinleyerek Rüzgâr İblisi'nin bulunduğu yere ulaşmayı başarmış. İblis'in sarayına vardığında karısını bulmuş ve onunla birlikte kaçmaya karar vermişler.",
      "Ancak kurtuluşları kolay olmamış. Rüzgâr İblisi uyandığında çiftin kaçtığını anlamış ve peşlerine düşmüş. Şehzade ile karısı kendilerini kurtarabilmek için yalnızca hızlı hareket etmekle yetinmemiş; İblis'in gücünün kaynağını da öğrenmeye çalışmışlar.",
      "Yardımcılarının rehberliği ve çiftin kararlılığı sayesinde İblis'in tılsımıyla ilgili sırrı öğrenme fırsatı doğmuş. Sonunda Rüzgâr İblisi'nin tehdidi ortadan kaldırılmış ve genç çift özgürlüklerine kavuşmuş. Masal, sevdiği kişiyi kurtarmak için mücadele etmenin ve yardım almanın önemini anlatır."
    ]
  },
  {
    title: "Karga Peri",
    teaser: "Bir kuş, bir sır ve hayatı değiştiren bir dostluk…",
    source: "Ignác Kúnos, Türk Masalları, Maya Kitap, 2018. Başlangıç sayfası: 116.",
    paragraphs: [
      "Bir zamanlar geçimini ormanda kuş yakalayarak sağlayan bir adam yaşarmış. Adamın ölümünden sonra oğlu yalnız kalmış ve babasının mesleğini sürdürmeye karar vermiş. Bir gün ormanda bir kapan kurmuş. Bir süre sonra bir karga kapana yakalanmış. Genç adam kuşu almak için ağaca tırmandığında karga ondan kendisini serbest bırakmasını istemiş. Karşılığında ona daha değerli bir şey kazandıracağını söylemiş.",
      "Genç adam kargayı bırakmış ve kapanını yeniden kurmuş. Bir süre sonra kapanına çok güzel bir kuş yakalanmış. Karga yeniden ortaya çıkarak genç adama bu kuşu padişaha götürmesini önermiş. Genç adam kuşu saraya götürmüş ve padişah kuşun güzelliğinden etkilenerek ona büyük miktarda para vermiş. Böylece yoksul genç bir anda zenginleşmiş.",
      "Ancak sarayda yaşayan kıskanç bir kişi bu durumdan rahatsız olmuş. Genç adamın kazandığı serveti ve padişahın ona gösterdiği ilgiyi kıskanmış. Genç adamı zor durumda bırakmak amacıyla padişaha yeni isteklerde bulunmasını önermiş. Önce kuşun yaşayabileceği özel bir saray yapılmasını istemiş, ardından genç adamdan başka zor görevleri yerine getirmesini beklemiş.",
      "Genç adam, karganın yardımıyla bu istekleri karşılamak üzere yeni maceralara atılmış. Her yeni görev onun cesaretini ve kendisine yol gösteren gizemli kargaya duyduğu güveni sınamış. Karga, genç adamın karşısına çıkan engelleri aşmasına yardımcı olmuş; saraydaki kıskanç kişinin planları ise beklediği sonucu vermemiş.",
      "Sonunda genç kuşçu ile karga-peri arasındaki bağın gerçek niteliği ortaya çıkmış. Genç adamın önüne engeller çıkaran kötü niyetli danışman sürgün edilmiş. Kuşçuya önemli bir görev verilmiş ve ikisi mutlu bir hayata kavuşmuş. Masal, iyilik, güven ve yardımlaşmanın önemini vurgular."
    ]
  }
];

const cards = Array.from(document.querySelectorAll(".story-card"));
const searchInput = document.getElementById("searchInput");
const resultsNote = document.getElementById("resultsNote");
const emptyState = document.getElementById("emptyState");
const reader = document.getElementById("reader");
const readerTitle = document.getElementById("readerTitle");
const readerMeta = document.getElementById("readerMeta");
const readerText = document.getElementById("readerText");
const readerSource = document.getElementById("readerSource");
const readerHint = document.getElementById("readerHint");

let currentStory = -1;
let textSize = 1;

function searchStories() {
  const term = searchInput.value.trim().toLocaleLowerCase("tr-TR");
  let count = 0;

  cards.forEach(function(card) {
    const story = stories[Number(card.dataset.story)];
    const searchable = (
      story.title + " " +
      story.teaser + " " +
      card.dataset.search
    ).toLocaleLowerCase("tr-TR");

    const match = searchable.includes(term);

    card.classList.toggle("hidden", !match);

    if (match) count++;
  });

  resultsNote.textContent = term
    ? count + " masal bulundu."
    : "Keşfedilmeyi bekleyen 8 masal var.";

  emptyState.style.display = count === 0 ? "block" : "none";
}

document.getElementById("searchForm").addEventListener("submit", function(event) {
  event.preventDefault();
  searchStories();
});

searchInput.addEventListener("input", searchStories);

function openStory(index) {
  if (index < 0 || index >= stories.length) return;

  currentStory = index;
  const story = stories[index];

  readerTitle.textContent = story.title;
  readerMeta.textContent =
    "Türk halk masalı · " + (index + 1) + " / " + stories.length;

  readerText.innerHTML = "";

  story.paragraphs.forEach(function(paragraph) {
    const p = document.createElement("p");
    p.textContent = paragraph;
    readerText.appendChild(p);
  });

  readerSource.textContent =
    "Kaynak bilgisi: " + story.source +
    " Bu metin, kaynak masalın sadeleştirilmiş özetidir.";

  reader.style.display = "block";
  reader.classList.add("active");
  readerHint.style.display = "none";
  readerText.style.fontSize = textSize + "rem";

  document.getElementById("prevStory").disabled = index === 0;
  document.getElementById("nextStory").disabled =
    index === stories.length - 1;

  reader.scrollIntoView({
    behavior: "smooth",
    block: "start"
  });
}

cards.forEach(function(card) {
  card.addEventListener("click", function() {
    openStory(Number(card.dataset.story));
  });
});

document.getElementById("prevStory").addEventListener("click", function() {
  if (currentStory > 0) {
    openStory(currentStory - 1);
  }
});

document.getElementById("nextStory").addEventListener("click", function() {
  if (currentStory < stories.length - 1) {
    openStory(currentStory + 1);
  }
});

document.getElementById("largerText").addEventListener("click", function() {
  textSize = Math.min(1.35, textSize + 0.1);
  readerText.style.fontSize = textSize + "rem";
});

document.getElementById("smallerText").addEventListener("click", function() {
  textSize = Math.max(0.85, textSize - 0.1);
  readerText.style.fontSize = textSize + "rem";
});